const express = require('express');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());
// Esto conecta tu servidor con la interfaz gráfica
app.use(express.static('public'));

// Tu API Key confirmada
const genAI = new GoogleGenerativeAI("AIzaSyAd_xB262lE251NkkdZZuTyLN0_o1oWTOg");

app.post('/chat', async (req, res) => {
  try {
      const { prompt } = req.body;
          const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
              
                  const result = await model.generateContent(prompt);
                      const response = await result.response;
                          const text = response.text();
                              
                                  res.json({ reply: text });
                                    } catch (error) {
                                        console.error("Error en Google AI:", error);
                                            res.status(500).json({ reply: "Error interno: " + error.message });
                                              }
                                              });

                                              app.listen(3000, () => {
                                                console.log('¡Cerebro de NOVA encendido en el puerto 3000!');
                                                });
                                                