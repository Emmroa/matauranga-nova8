import React, { useState } from "react";
import "./styles.css";

export default function App() {
  const [messages, setMessages] = useState([
    { text: "Kia ora. Soy NOVA. ¿En qué puedo apoyarte hoy?", sender: "nova" },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);

  const handleSend = async () => {
    if (!input.trim()) return;

    const newMessages = [...messages, { text: input, sender: "user" }];
    setMessages(newMessages);
    setInput("");
    setIsTyping(true);

    try {
      // NOVA ahora se conecta a TU servidor seguro
      const response = await fetch("http://localhost:3000/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: input }),
      });

      const data = await response.json();
      const respuestaFinal =
        data.reply || "Lo siento, recibí una respuesta vacía.";

      setMessages([...newMessages, { text: respuestaFinal, sender: "nova" }]);
    } catch (error) {
      setMessages([
        ...newMessages,
        { text: "Error de conexión con el cerebro de NOVA.", sender: "nova" },
      ]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="nova-container">
      <header className="nova-header">
        <div className="nova-brand">Mātauranga NOVA</div>
      </header>

      <div className="chat-window">
        {messages.map((m, i) => (
          <div key={i} className={`message-bubble ${m.sender}`}>
            {m.text}
          </div>
        ))}
        {isTyping && (
          <div className="typing-indicator">Nova está pensando...</div>
        )}
      </div>

      <div className="input-area">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={(e) => e.key === "Enter" && handleSend()}
          placeholder="Escribe un mensaje..."
        />
        <button onClick={handleSend} className="send-btn">
          Enviar
        </button>
      </div>
    </div>
  );
}
